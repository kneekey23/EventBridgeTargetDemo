import json
import boto3
import base64
import requests

def lambda_handler(event, context):
    # TODO implement

    comment = event['detail']['ticket_event']['comment']['body']
    user_id = event['detail']['ticket_event']['ticket']['requester_id']
    ticket_id = event['detail']['ticket_event']['ticket']['id']
    ticket = event['detail']['ticket_event']['ticket']
    
    comprehend_client = boto3.client('comprehend', region_name='us-west-2')
    
    response = comprehend_client.detect_sentiment(
    Text=comment,
    LanguageCode='en')
    print(response)
    
    if response['Sentiment'] == 'NEGATIVE':
        #publish to sns topic to notify by email
        sns_client = boto3.client('sns')
        sns_response = sns_client.publish(
        TopicArn='arn:aws:sns:us-west-1:805580953652:NegativeZenDeskTicket',
        Message=comment + ' from user ' + str(user_id),
        Subject='Negative Ticket Alert')
            
        print(sns_response)
        # hit zendesk api to update that ticket with priority support tag
        
        base_zendesk_api_url = 'https://z3n-developer.zendesk.com/api/v2/tickets/{}.json'.format(ticket_id)
        auth = 'nickik@amazon.com/token:DIkn8fdSGHLQTcp6AIlvW4fZfM5Yr8tdbu6mMERy'
        base_64_encoded_auth = base64.b64encode(auth.encoded())
        
        #update ticket
        ticket['priority'] = 'urgent'
        ticket['tags'] = ['Priority Support'] 
        headers = {'Content-Type': 'application/json', 'Authorization': base_64_encoded_auth}
        zendesk_response = requests.put(base_zendesk_api_url, headers=headers, data=ticket)
        print(zendesk_response)
        
    else :
        print('sentiment is positive, do nothing yay!')
    
